package com.example.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.example.employee.entity.Employee;


@Service
public class EmployeeService {
	List<Employee> employees = new ArrayList<>();

	@PostConstruct
	public void initDB() {
		
		employees.add(new Employee(1,"Sunny","Vellanki","964081559","Hyderabad","Full Satck"));
		employees.add(new Employee(2,"Harika","pulluri","964081559","Hyderabad","Full Satck"));
		 
		
			}
	
	public List<Employee> getAllEmployees(){
		return employees;
	}
	
	public Employee addEmployee(Employee e) {
		employees.add(e);
		return e;
	}
	public Employee updateEmployee(int id,String fn) {
		Employee e1=new Employee();
		//System.out.println(fn);
		for(Employee e:employees) {
			if(e.getUserId()==id) {
				e.setFirstName(fn);
				e1=e;
			}
		}
		return e1;
	}
	public String deleteEmployee(int id) {
		ListIterator<Employee> listIterator= employees.listIterator();
		System.out.println("--service---");
		String str="";
		while(listIterator.hasNext()) {
			if(listIterator.next().getUserId()==id) {
				System.out.println("--inside loop---");
				str="Successfully deleted!!";
				listIterator.remove();
			}
		}
		return str;
	}
	
}
