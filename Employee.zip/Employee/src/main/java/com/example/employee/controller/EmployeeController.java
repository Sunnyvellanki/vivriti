package com.example.employee.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee.entity.Employee;
import com.example.employee.service.EmployeeService;

@RestController
@RequestMapping("employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getall")
	public List<Employee> getAllEmployees(){
		return employeeService.getAllEmployees();
		
	}
	
	@PostMapping("/addemployee")
	public Employee addEmployee(@RequestBody Employee employee) {
		Employee emp=new Employee();
		emp=employeeService.addEmployee(employee);
		return emp;
	}
	
	@PutMapping("/updateemployee/{userid}")
	public Employee updateEmployee(@PathVariable int userid, @RequestBody String firstname) {
		Employee emp=new Employee();
		
		return employeeService.updateEmployee(userid,firstname);
		
	}
	
	@DeleteMapping("/deleteemployee/{userid}")
	public String deleteEmployee(@PathVariable int userid) {
		System.out.println("--controller---");
		return employeeService.deleteEmployee(userid);
	}
	

}
